# -*- coding: utf-8 -*-
import os
from qgis.PyQt.QtWidgets import QAction, QFileDialog, QMessageBox, QDialog, QVBoxLayout, QTextEdit, QDialogButtonBox, QApplication
from qgis.PyQt.QtGui import QColor
from qgis.core import (QgsProject, QgsVectorLayer, QgsRuleBasedRenderer, QgsMarkerSymbol, QgsLineSymbol,
                       QgsFillSymbol, QgsPalLayerSettings, QgsVectorLayerSimpleLabeling, QgsTextFormat, Qgis)
from . import terra_pacote as tp

MENU = "&Terra Geo"
CAMADAS = ["imovel", "limites", "vertices", "proprietarios", "confrontantes", "processo", "documentos"]


class TerraPacotePlugin:
    def __init__(self, iface):
        self.iface = iface
        self.acoes = []

    # ------------------------------------------------ ciclo de vida
    def initGui(self):
        for txt, fn in [("Abrir Pacote do Imóvel…", self.abrir), ("Validar pacote (NTGIR)", self.validar),
                        ("Recalcular (UTM, σH, lados, área)", self.recalcular),
                        ("Descrição perimetral", self.descricao), ("Exportar .terra.json (portal/app)", self.exportar_json),
                        ("Novo pacote vazio…", self.novo)]:
            a = QAction(txt, self.iface.mainWindow())
            a.triggered.connect(fn)
            self.iface.addPluginToVectorMenu(MENU, a)
            self.acoes.append(a)

    def unload(self):
        for a in self.acoes:
            self.iface.removePluginVectorMenu(MENU, a)
        self.acoes = []

    # ------------------------------------------------ utilidades
    def _msg(self, txt, nivel=Qgis.Info):
        self.iface.messageBar().pushMessage("Terra Geo", txt, level=nivel, duration=6)

    def _caminho_ativo(self):
        lyr = self.iface.activeLayer()
        if lyr is None or lyr.providerType() != "ogr":
            self._msg("Selecione uma camada do Pacote do Imóvel no painel de camadas.", Qgis.Warning)
            return None
        cam = lyr.source().split("|")[0]
        if not cam.lower().endswith(".gpkg"):
            self._msg("A camada ativa não é de um Pacote do Imóvel (.gpkg).", Qgis.Warning)
            return None
        # salva edições pendentes das camadas desse arquivo
        for l in QgsProject.instance().mapLayers().values():
            if l.source().split("|")[0] == cam and hasattr(l, "isEditable") and l.isEditable():
                l.commitChanges()
        return cam

    def _camadas_do(self, cam):
        return [l for l in QgsProject.instance().mapLayers().values() if l.source().split("|")[0] == cam]

    def _estilizar(self, lyr, nome):
        if nome == "vertices":
            raiz = QgsRuleBasedRenderer.Rule(None)
            for rotulo, expr, cor in [("Dentro da tolerância", '"dentro_tolerancia" = 1', "#1F9E4A"),
                                       ("Fora da tolerância", '"dentro_tolerancia" = 0', "#D7263D"),
                                       ("Sem sigma", '"dentro_tolerancia" IS NULL', "#9AA5A0")]:
                s = QgsMarkerSymbol.createSimple({"name": "circle", "color": cor, "outline_color": "#24473A", "size": "2.6"})
                raiz.appendChild(QgsRuleBasedRenderer.Rule(s, 0, 0, expr, rotulo))
            lyr.setRenderer(QgsRuleBasedRenderer(raiz))
            pal = QgsPalLayerSettings()
            pal.fieldName = "codigo"
            fmt = QgsTextFormat()
            fmt.setSize(8)
            fmt.setColor(QColor("#24473A"))
            pal.setFormat(fmt)
            lyr.setLabeling(QgsVectorLayerSimpleLabeling(pal))
            lyr.setLabelsEnabled(True)
        elif nome == "limites":
            lyr.renderer().setSymbol(QgsLineSymbol.createSimple({"color": "#24473A", "width": "0.6"}))
        elif nome == "imovel":
            lyr.renderer().setSymbol(QgsFillSymbol.createSimple(
                {"color": "31,158,74,40", "outline_color": "#1F9E4A", "outline_width": "0.8"}))
        lyr.triggerRepaint()

    def _carregar(self, cam):
        pac = tp.ler_gpkg(cam)
        titulo = pac["imovel"].get("denominacao") or os.path.basename(cam)
        raiz = QgsProject.instance().layerTreeRoot()
        grupo = raiz.insertGroup(0, f"🏷 {titulo}")
        for nome in CAMADAS:
            lyr = QgsVectorLayer(f"{cam}|layername={nome}", nome, "ogr")
            if not lyr.isValid():
                continue
            QgsProject.instance().addMapLayer(lyr, False)
            grupo.addLayer(lyr)
            self._estilizar(lyr, nome)
        im = next((l for l in self._camadas_do(cam) if l.name() == "imovel"), None)
        if im and im.featureCount():
            self.iface.mapCanvas().setExtent(im.extent().buffered(im.extent().width() * 0.1 + 10))
            self.iface.mapCanvas().refresh()
        return pac

    # ------------------------------------------------ ações
    def abrir(self):
        cam, _ = QFileDialog.getOpenFileName(self.iface.mainWindow(), "Abrir Pacote do Imóvel", "",
                                             "Pacote do Imóvel (*.gpkg *.terra.json *.json)")
        if not cam:
            return
        try:
            if not cam.lower().endswith(".gpkg"):
                pac = tp.normalizar(tp.ler_json(cam))
                destino = cam.replace(".terra.json", "").replace(".json", "") + ".gpkg"
                if os.path.exists(destino) and self._camadas_do(destino):
                    self._msg("Esse pacote já está aberto. Feche as camadas dele antes de reimportar.", Qgis.Warning)
                    return
                tp.registrar_etapa(pac, pac["imovel"].get("etapa_atual") or "CAMPO", "TERRA_GEO_TOOLS",
                                   f"Importado de {os.path.basename(cam)}")
                tp.gravar_gpkg(pac, destino)
                cam = destino
            self._carregar(cam)
            self._msg(f"Pacote aberto: {os.path.basename(cam)}", Qgis.Success)
        except Exception as e:
            QMessageBox.critical(self.iface.mainWindow(), "Terra Geo", f"Não foi possível abrir o pacote:\n{e}")

    def novo(self):
        cam, _ = QFileDialog.getSaveFileName(self.iface.mainWindow(), "Novo Pacote do Imóvel", "", "GeoPackage (*.gpkg)")
        if not cam:
            return
        if not cam.lower().endswith(".gpkg"):
            cam += ".gpkg"
        tp.gravar_gpkg(tp.novo(denominacao=os.path.splitext(os.path.basename(cam))[0]), cam)
        self._carregar(cam)
        self._msg("Pacote criado. Digitalize/importe os vértices na camada 'vertices' e use Recalcular.", Qgis.Success)

    def validar(self):
        cam = self._caminho_ativo()
        if not cam:
            return
        res = tp.validar(tp.normalizar(tp.ler_gpkg(cam)))
        erros = sum(1 for n, _ in res if n == "ERRO")
        self._mostrar("Validação NTGIR", "\n".join(f"[{n}] {m}" for n, m in res))
        self._msg(f"Validação: {erros} erro(s).", Qgis.Critical if erros else Qgis.Success)

    def recalcular(self):
        cam = self._caminho_ativo()
        if not cam:
            return
        pac = tp.normalizar(tp.ler_gpkg(cam))
        tp.registrar_etapa(pac, "PROCESSAMENTO", "TERRA_GEO_TOOLS", "Recalculado no QGIS")
        for l in self._camadas_do(cam):          # libera o arquivo antes de regravar
            QgsProject.instance().removeMapLayer(l.id())
        raiz = QgsProject.instance().layerTreeRoot()
        for g in raiz.findGroups():
            if not g.children():
                raiz.removeChildNode(g)
        tp.gravar_gpkg(pac, cam)
        self._carregar(cam)
        self._msg(f"Recalculado: {pac['imovel']['area_utm_ha']} ha (UTM), perímetro {pac['imovel']['perimetro_utm_m']} m.", Qgis.Success)

    def descricao(self):
        cam = self._caminho_ativo()
        if cam:
            txt = tp.descricao_perimetral(tp.normalizar(tp.ler_gpkg(cam)))
            QApplication.clipboard().setText(txt)
            self._mostrar("Descrição perimetral (copiada)", txt)

    def exportar_json(self):
        cam = self._caminho_ativo()
        if not cam:
            return
        destino, _ = QFileDialog.getSaveFileName(self.iface.mainWindow(), "Exportar para portal/app",
                                                 cam[:-5] + ".terra.json", "Pacote JSON (*.terra.json)")
        if destino:
            tp.gravar_json(tp.normalizar(tp.ler_gpkg(cam)), destino)
            self._msg(f"Exportado: {os.path.basename(destino)}", Qgis.Success)

    def _mostrar(self, titulo, texto):
        d = QDialog(self.iface.mainWindow())
        d.setWindowTitle(titulo)
        d.resize(640, 420)
        lay = QVBoxLayout(d)
        t = QTextEdit()
        t.setPlainText(texto)
        t.setReadOnly(True)
        lay.addWidget(t)
        b = QDialogButtonBox(QDialogButtonBox.Close)
        b.rejected.connect(d.reject)
        lay.addWidget(b)
        d.exec_()
