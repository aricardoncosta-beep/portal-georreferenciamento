def classFactory(iface):
    from .plugin import TerraPacotePlugin
    return TerraPacotePlugin(iface)
